package com.wipro.book.bean;

public class AuthorBean {
	int authorCode;
	String authorName;
	long contactNo;
	public int getAuthorCode() {
		return authorCode;
	}
	public void setAuthorCode(int authorCode) {
		this.authorCode = authorCode;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}

}
